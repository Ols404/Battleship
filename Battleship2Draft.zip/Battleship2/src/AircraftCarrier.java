public class AircraftCarrier extends Ship {
}
