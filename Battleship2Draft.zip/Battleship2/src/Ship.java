public class Ship {
    protected char shipSymbol;
    protected int shipSize;
}
