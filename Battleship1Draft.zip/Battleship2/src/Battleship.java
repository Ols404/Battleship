public class Battleship extends Ship {
}
