//Extension Idea: play music in the background lmfao (Naval Action - Naval Battle Music - Background Atmosphere Music)
//Actually make your class fields for the ships do something xD

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ArrayList<String> trackHitMiss = new ArrayList<String>();

        boolean boardCondition = true;

        char[][] gameBoard = new char[10][10];
        char[][] gameBoardDummy = new char[10][10];

        //Note that the default ship is the battleship

        AircraftCarrier aircraftCarrier = new AircraftCarrier();
        Battleship battleship = new Battleship();
        Cruiser cruiser = new Cruiser();
        Destroyers destroyersShip = new Destroyers();

        aircraftCarrier.shipSize = 5;
        aircraftCarrier.shipSymbol = 'A';
        int airCraftShipNumber = 5;
        char aircraftShipSymbol = 'A';

        battleship.shipSize = 4;
        battleship.shipSymbol = 'B';
        int defaultShipNumber = 4;
        char defaultShipSymbol = 'B';

        cruiser.shipSize = 3;
        cruiser.shipSymbol = 'C';
        int cruiserNumber = 3;
        char cruiserSymbol = 'C';

        destroyersShip.shipSize = 2;
        destroyersShip.shipSymbol = 'D';
        int destroyersNumber = 2;
        char destroyersSymbol = 'D';

        int totalShipNumber = 16;

        char waterSymbol = '-';

        int numMissilesFired = 0;
        int numMissilesHit = 0;
        int numMissilesMiss = 0;

        int difficulty = 0;

            char[][] updatedGameBoard = gameBoardCreation(gameBoard);

            System.out.println();
            System.out.println();
            System.out.println();

            while (boardCondition) {
                try {
                    char[][] updatedGameBoard2 = placeDefaultShipsVersion2(updatedGameBoard, defaultShipNumber, defaultShipSymbol, waterSymbol, airCraftShipNumber, aircraftShipSymbol, cruiserSymbol, cruiserNumber, destroyersSymbol, destroyersNumber);
                    boardCondition = false;
                } catch (Exception e) {
                    System.exit(1);
                }
            }

            System.out.println();
            System.out.println();
            System.out.println("************************************************************************************************************************************************************************************************");
            System.out.println();
            System.out.println();

            gameBoardCreation(gameBoardDummy);

            System.out.println("Welcome to Battleship! :D");
            System.out.println("What would you like the difficulty of the game to be?");
            Scanner scannerDifficulty = new Scanner(System.in);
            String scannerDifficultyInput = scannerDifficulty.nextLine();
            if (scannerDifficultyInput.equalsIgnoreCase("Easy")) {
                difficulty = 100;
            } else if (scannerDifficultyInput.equalsIgnoreCase("Medium")) {
                difficulty = 50;
            } else if (scannerDifficultyInput.equalsIgnoreCase("Hard")) {
                difficulty = 25;
            }
            System.out.println("Sounds good! You are currently playing on " + scannerDifficultyInput + " difficulty.");
            System.out.println();


            while (totalShipNumber > 0 && difficulty > 0) {
                System.out.println("Possible Commands: ");
                System.out.println("View Ships(VSP) - displays the placement of the ships");
                System.out.println("Fire(fire) - fires a missle at the cell [r][c]");
                System.out.println("Stats(stats) - prints out the game statistics");
                System.out.println("Track(track) - prints out a record of all your missiles");

                Scanner scannerChoice = new Scanner(System.in);
                String scannerPlayerFirstChoice = scannerChoice.nextLine();
                if (scannerPlayerFirstChoice.equalsIgnoreCase("fire")) {
                    System.out.println("Take your shot!");
                    Scanner shotInput = new Scanner(System.in);
                    System.out.println("Row: ");
                    int shotInputX = shotInput.nextInt();
                    System.out.println("Column: ");
                    int shotInputY = shotInput.nextInt();

                    shotInputX -= 1;
                    shotInputY -= 1;

                    if (updatedGameBoard[shotInputX][shotInputY] == destroyersSymbol || updatedGameBoard[shotInputX][shotInputY] == cruiserSymbol || updatedGameBoard[shotInputX][shotInputY] == defaultShipSymbol || updatedGameBoard[shotInputX][shotInputY] == aircraftShipSymbol) {
                        System.out.println("Hit!");
                        numMissilesFired++;
                        numMissilesHit++;
                        totalShipNumber--;
                        difficulty--;
                        trackHitMiss.add("Hit");
                        updatedGameBoard[shotInputX][shotInputY] = 'X';
                        gameBoardDummy[shotInputX][shotInputY] = 'X';
                    } else if (updatedGameBoard[shotInputX][shotInputY] == waterSymbol) {
                        System.out.println("Miss!");
                        numMissilesFired++;
                        numMissilesMiss++;
                        difficulty--;
                        trackHitMiss.add("Miss");
                        updatedGameBoard[shotInputX][shotInputY] = 'O';
                        gameBoardDummy[shotInputX][shotInputY] = 'O';
                    }

                    updateGameBoardAfterShot(gameBoardDummy);

                } else if (scannerPlayerFirstChoice.equalsIgnoreCase("stats")) {
                    System.out.println("Number of ships sunk: " + numMissilesHit);
                    System.out.println("Number of missiles fired: " + numMissilesFired);
                    System.out.println("Hit ratio: " + numMissilesHit + "/" + numMissilesFired);

                    updateGameBoardAfterShot(gameBoardDummy);

                } else if (scannerPlayerFirstChoice.equalsIgnoreCase("VSP")) {
                    updateGameBoardAfterShot(updatedGameBoard);
                } else if (scannerPlayerFirstChoice.equalsIgnoreCase("track")){
                    System.out.println(trackHitMiss.toString());
                }

            }

            if (totalShipNumber == 0 && difficulty > 0) {
                System.out.println("You won! :D");
            } else if (totalShipNumber > 0 && difficulty == 0) {
                System.out.println("You lost! :(");
            }
    }

    public static char[][] gameBoardCreation(char[][] gameBoard) {
        System.out.print("  "); //For the formatting of the board and to shift it two spots to the right.
        for(int i = 0; i < gameBoard.length; i++){   //column index
            System.out.print(i + 1 + " ");
        }
        System.out.println();
        for (int i = 0; i < gameBoard.length; i++) {
            System.out.print(i + 1 + " ");
            for (int j = 0; j < gameBoard[i].length; j++) {
                gameBoard[i][j] = '-';
                System.out.print(gameBoard[i][j] + " ");
            }
            System.out.println();
        }
        return gameBoard;
    }

    public static char[][] placeDefaultShipsVersion2(char[][] gameBoard, int shipNumber, char shipSymbol, char waterSymbol, int airCraftShipNumber, char airCraftShipSymbol, char cruiserSymbol, int cruiserNumber, char destroyerSymbol, int destroyerNumber) {


        //Default Ship Conditions
        Random randomCoords = new Random();
        int randomX = randomCoords.nextInt(10);
        int randomY = randomCoords.nextInt(10);

        //These two comments below are the actual values of the points on the board
        //System.out.println(randomX + 1);
        //System.out.println(randomY + 1);

        if (randomX + shipNumber < 10 && randomX + shipNumber > 0) {
            if (gameBoard[randomX][randomY] == waterSymbol) {
                gameBoard[randomX][randomY] = shipSymbol;
                for (int i = 0; i < shipNumber; i++) {
                    gameBoard[randomX][randomY + i] = shipSymbol;
                }
            }
        } else if (randomX - shipNumber > 0 && randomX - shipNumber < 10) {
            if (gameBoard[randomX][randomY] == waterSymbol) {
                gameBoard[randomX][randomY] = shipSymbol;
                for (int i = 0; i < shipNumber; i++) {
                    gameBoard[randomX][randomY - i] = shipSymbol;
                }
            }
        } else if (randomY + shipNumber < 10 && randomY + shipNumber > 0) {
            if (gameBoard[randomX][randomY] == waterSymbol) {
                gameBoard[randomX][randomY] = shipSymbol;
                for (int i = 0; i < shipNumber; i++) {
                    gameBoard[randomX + i][randomY] = shipSymbol;
                }
            }
        } else if (randomY - shipNumber > 0 && randomY - shipNumber < 10) {
            if (gameBoard[randomX][randomY] == waterSymbol) {
                gameBoard[randomX][randomY] = shipSymbol;
                for (int i = 0; i < shipNumber; i++) {
                    gameBoard[randomX - i][randomY] = shipSymbol;
                }
            }
        }



        //Aircraft Carrier Conditions
        Random randomCoords1 = new Random();
        int randomX1 = randomCoords1.nextInt(10);
        int randomY1 = randomCoords1.nextInt(10);


        if (randomX1 + airCraftShipNumber < 10 && randomX1 + airCraftShipNumber > 0) {
            if (gameBoard[randomX1][randomY1] == waterSymbol && gameBoard[randomX1][randomY1] != shipSymbol) {
                gameBoard[randomX1][randomY1] = airCraftShipSymbol;
                for (int i = 0; i < airCraftShipNumber; i++) {
                    gameBoard[randomX1 + i][randomY1] = airCraftShipSymbol;
                }
            }
        } else if (randomX1 - airCraftShipNumber > 0 && randomX1 - airCraftShipNumber < 10) {
            if (gameBoard[randomX1][randomY1] == waterSymbol && gameBoard[randomX1][randomY1] != shipSymbol) {
                gameBoard[randomX1][randomY1] = airCraftShipSymbol;
                for (int i = 0; i < airCraftShipNumber; i++) {
                    gameBoard[randomX1 - i][randomY1] = airCraftShipSymbol;
                }
            }
        } else if (randomY1 + airCraftShipNumber < 10 && randomY1 + airCraftShipNumber > 0) {
            if (gameBoard[randomX1][randomY1] == waterSymbol && gameBoard[randomX1][randomY1] != shipSymbol) {
                gameBoard[randomX1][randomY1] = airCraftShipSymbol;
                for (int i = 0; i < airCraftShipNumber; i++) {
                    gameBoard[randomX1][randomY1 + i] = airCraftShipSymbol;
                }
            }
        } else if (randomY1 - airCraftShipNumber > 0 && randomY1 - airCraftShipNumber < 10) {
            if (gameBoard[randomX1][randomY1] == waterSymbol && gameBoard[randomX1][randomY1] != shipSymbol) {
                gameBoard[randomX1][randomY1] = airCraftShipSymbol;
                for (int i = 0; i < airCraftShipNumber; i++) {
                    gameBoard[randomX1][randomY1 - i] = airCraftShipSymbol;
                }
            }
        }

        //Cruiser Conditions
        Random randomCoords2 = new Random();
        int randomX2 = randomCoords2.nextInt(10);
        int randomY2 = randomCoords2.nextInt(10);


        if (randomX2 + cruiserNumber < 10 && randomX2 + cruiserNumber > 0) {
            if (gameBoard[randomX2][randomY2] == waterSymbol && gameBoard[randomX2][randomY2] != shipSymbol && gameBoard[randomX2][randomY2] != airCraftShipSymbol) {
                gameBoard[randomX2][randomY2] = cruiserSymbol;
                for (int i = 0; i < cruiserNumber; i++) {
                    gameBoard[randomX2 + i][randomY2] = cruiserSymbol;
                }
            }
        } else if (randomX2 - cruiserNumber > 0 && randomX2 - cruiserNumber < 10) {
            if (gameBoard[randomX2][randomY2] == waterSymbol && gameBoard[randomX2][randomY2] != shipSymbol && gameBoard[randomX2][randomY2] != airCraftShipSymbol) {
                gameBoard[randomX2][randomY2] = cruiserSymbol;
                for (int i = 0; i < cruiserNumber; i++) {
                    gameBoard[randomX2 - i][randomY2] = cruiserSymbol;
                }
            }
        } else if (randomY2 + cruiserNumber < 10 && randomY2 + cruiserNumber > 0) {
            if (gameBoard[randomX2][randomY2] == waterSymbol && gameBoard[randomX2][randomY2] != shipSymbol && gameBoard[randomX2][randomY2] != airCraftShipSymbol) {
                gameBoard[randomX2][randomY2] = cruiserSymbol;
                for (int i = 0; i < cruiserNumber; i++) {
                    gameBoard[randomX2][randomY2 + i] = cruiserSymbol;
                }
            }
        } else if (randomY2 - cruiserNumber > 0 && randomY2 - cruiserNumber < 10) {
            if (gameBoard[randomX2][randomY2] == waterSymbol && gameBoard[randomX2][randomY2] != shipSymbol && gameBoard[randomX2][randomY2] != airCraftShipSymbol) {
                gameBoard[randomX2][randomY2] = cruiserSymbol;
                for (int i = 0; i < cruiserNumber; i++) {
                    gameBoard[randomX2][randomY2 - i] = cruiserSymbol;
                }
            }
        }

        //Destroyer Conditions
        Random randomCoords3 = new Random();
        int randomX3 = randomCoords3.nextInt(10);
        int randomY3 = randomCoords3.nextInt(10);

        Random randomCoords4 = new Random();
        int randomX4 = randomCoords3.nextInt(10);
        int randomY4 = randomCoords3.nextInt(10);


        if (randomX3 + destroyerNumber < 10 && randomX3 + destroyerNumber > 0) {
            if (gameBoard[randomX3][randomY3] == waterSymbol && gameBoard[randomX3][randomY3] != shipSymbol && gameBoard[randomX3][randomY3] != airCraftShipSymbol && gameBoard[randomX3][randomY3] != cruiserSymbol) {
                gameBoard[randomX3][randomY3] = destroyerSymbol;
                for (int i = 0; i < destroyerNumber; i++) {
                    gameBoard[randomX3][randomY3 + i] = destroyerSymbol;
                }
            }
        } else if (randomX3 - destroyerNumber > 0 && randomX3 - destroyerNumber < 10) {
            if (gameBoard[randomX3][randomY3] == waterSymbol && gameBoard[randomX3][randomY3] != shipSymbol && gameBoard[randomX3][randomY3] != airCraftShipSymbol && gameBoard[randomX3][randomY3] != cruiserSymbol) {
                gameBoard[randomX3][randomY3] = destroyerSymbol;
                for (int i = 0; i < destroyerNumber; i++) {
                    gameBoard[randomX3][randomY3 - i] = destroyerSymbol;
                }
            }
        } else if (randomY3 + destroyerNumber < 10 && randomY3 + destroyerNumber > 0) {
            if (gameBoard[randomX3][randomY3] == waterSymbol && gameBoard[randomX3][randomY3] != shipSymbol && gameBoard[randomX3][randomY3] != airCraftShipSymbol && gameBoard[randomX3][randomY3] != cruiserSymbol) {
                gameBoard[randomX3][randomY3] = destroyerSymbol;
                for (int i = 0; i < destroyerNumber; i++) {
                    gameBoard[randomX3 + i][randomY3] = destroyerSymbol;
                }
            }
        } else if (randomY3 - destroyerNumber > 0 && randomY3 - destroyerNumber < 10) {
            if (gameBoard[randomX3][randomY3] == waterSymbol && gameBoard[randomX3][randomY3] != shipSymbol && gameBoard[randomX3][randomY3] != airCraftShipSymbol && gameBoard[randomX3][randomY3] != cruiserSymbol) {
                gameBoard[randomX3][randomY3] = destroyerSymbol;
                for (int i = 0; i < destroyerNumber; i++) {
                    gameBoard[randomX3 - i][randomY3] = destroyerSymbol;
                }
            }
        }

        if (randomX4 + destroyerNumber < 10 && randomX4 + destroyerNumber > 0) {
            if (gameBoard[randomX4][randomY4] == waterSymbol && gameBoard[randomX4][randomY4] != shipSymbol && gameBoard[randomX4][randomY4] != airCraftShipSymbol && gameBoard[randomX4][randomY4] != cruiserSymbol && gameBoard[randomX4][randomY4] != destroyerSymbol) {
                gameBoard[randomX4][randomY4] = destroyerSymbol;
                for (int i = 0; i < destroyerNumber; i++) {
                    gameBoard[randomX4 + i][randomY4] = destroyerSymbol;
                }
            }
        } else if (randomX4 - destroyerNumber > 0 && randomX4 - destroyerNumber < 10) {
            if (gameBoard[randomX4][randomY4] == waterSymbol && gameBoard[randomX4][randomY4] != shipSymbol && gameBoard[randomX4][randomY4] != airCraftShipSymbol && gameBoard[randomX4][randomY4] != cruiserSymbol && gameBoard[randomX4][randomY4] != destroyerSymbol) {
                gameBoard[randomX3][randomY4] = destroyerSymbol;
                for (int i = 0; i < destroyerNumber; i++) {
                    gameBoard[randomX4 - i][randomY4] = destroyerSymbol;
                }
            }
        } else if (randomY4 + destroyerNumber < 10 && randomY4 + destroyerNumber > 0) {
            if (gameBoard[randomX4][randomY4] == waterSymbol && gameBoard[randomX4][randomY4] != shipSymbol && gameBoard[randomX4][randomY4] != airCraftShipSymbol && gameBoard[randomX4][randomY4] != cruiserSymbol && gameBoard[randomX4][randomY4] != destroyerSymbol) {
                gameBoard[randomX4][randomY4] = destroyerSymbol;
                for (int i = 0; i < destroyerNumber; i++) {
                    gameBoard[randomX4][randomY4 + i] = destroyerSymbol;
                }
            }
        } else if (randomY4 - destroyerNumber > 0 && randomY4 - destroyerNumber < 10) {
            if (gameBoard[randomX4][randomY4] == waterSymbol && gameBoard[randomX4][randomY4] != shipSymbol && gameBoard[randomX4][randomY4] != airCraftShipSymbol && gameBoard[randomX4][randomY4] != cruiserSymbol && gameBoard[randomX4][randomY4] != destroyerSymbol) {
                gameBoard[randomX4][randomY4] = destroyerSymbol;
                for (int i = 0; i < destroyerNumber; i++) {
                    gameBoard[randomX4][randomY4 - i] = destroyerSymbol;
                }
            }
        }


        System.out.print("  "); //For the formatting of the board and to shift it two spots to the right.
        for(int i = 0; i < gameBoard.length; i++){   //column index
            System.out.print(i + 1 + " ");
        }
        System.out.println();
        for (int i = 0; i < gameBoard.length; i++) {
            System.out.print(i + 1 + " ");
            for (int j = 0; j < gameBoard[i].length; j++) {
                System.out.print(gameBoard[i][j] + " ");
            }
            System.out.println();
        }
        return gameBoard;

    }

    public static char[][] updateGameBoardAfterShot(char[][] gameBoard){
        System.out.print("  "); //For the formatting of the board and to shift it two spots to the right.
        for(int i = 0; i < gameBoard.length; i++){   //column index
            System.out.print(i + 1 + " ");
        }
        System.out.println();
        for (int i = 0; i < gameBoard.length; i++) {
            System.out.print(i + 1 + " ");
            for (int j = 0; j < gameBoard[i].length; j++) {
                System.out.print(gameBoard[i][j] + " ");
            }
            System.out.println();
        }
        return gameBoard;
    }

}