public class Destroyers extends Ship {

}
