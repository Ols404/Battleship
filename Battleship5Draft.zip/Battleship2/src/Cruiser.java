public class Cruiser extends Ship {

}
