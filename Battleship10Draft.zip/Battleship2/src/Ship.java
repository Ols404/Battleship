//Base class that contains everything all the ships need

public class Ship {
    private static char shipSymbol;
    private static int shipSize;

//A few getters and setters that is inherited by all the different types of ships
    public static void setSymbol(char shipSymbolV){
        shipSymbol = shipSymbolV;
    }

    public static char getSymbol(){
        return shipSymbol;
    }

    public static void setShipSize(int shipSizeV){
        shipSize = shipSizeV;
    }

    public static int getShipSize(){
        return shipSize;
    }

}
